Dane Backbier - dbackbie - dbackbie@u.rochester.edu - Lab 4

Lab 4 is aimed at implementing a list ADT, using a linked list and array list. There are
6 java files in this zip file, URALTest.java, URLLTest.java, URArrayList.java,
URLinkedList.java, URList.java, and URNode.java. The ones coded by me were URALTest.java,
URLLTest.java, URArrayList.java, and URLinkedList.java. URList.java and URNode.java
were provided by the assignment. URLLTest.java is used to test URLinkedList.java and
URALTest.java is used to test URArrayList.java. To test, simply run both test files.
If everything is outputted into the terminal with no error messages and as expected, then
the program ran successfully. lab04.pdf is instruction file for this lab.