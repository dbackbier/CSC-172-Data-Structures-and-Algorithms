Dane Backbier - dbackbie@u.rochester.edu

The purpose for Lab #1 - Generics Review for CSC 172 is to better understand the
differences between and advantages for utilizing generic programming techniques
rather than non-generic programming techniques. Additionally, this lab is meant to
allow ymyself to be confident in doing any programming project involving Java generics, 
as well as being able to convert a non-generic program into a generic program. 
lab1.java is a file containing my solutions for parts 1 through 5, findMax.java
is a file containing my solution for part 6, OUTPUT.txt is a file containing
output from each part after running and compiling the code, and lab01.pdf is a 
pdf file of all the lab instructions provided from Blackboard.